﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Online_Patient_Appoientment.Models;

namespace Online_Patient_Appoientment.Controllers
{
    public class AddminController : Controller
    {
        //
        // GET: /Addmin/
        opaEntities db = new opaEntities();
        public ActionResult Index()
        {
            if (Session["aid"] != null)
            {

            }
            else
            {
                Response.Write("<script>alert('Login First then go to Next Zone');window.location.href='/Home/Login'</script>");
            }
            return View();
        }

        public ActionResult RegistrstionManger()
        {
            if (Session["aid"] !=null)
            {
            }
            else
            {
                Response.Write("<script>alert('Login First then go to Next Zone');window.location.href='/Home/Login'</script>");
            }
            List<TBL_Register> Lst = null;
            Lst = db.TBL_Register.ToList();
            return View(Lst);
        }
        public void Delete()
        {

            try
            {
                string m = Request.QueryString["m"];
                TBL_Register tbl1 = db.TBL_Register.SingleOrDefault(x => x.Email == m);
                db.TBL_Register.Remove(tbl1);
                db.SaveChanges();
                Response.Write("<script>alert('request delete successfull');window.location.href='/Addmin/RegistrstionManger'</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('not deleted');window.location.href='/Addmin/RegistrstionManger'</script>");
            }
        }

        public ActionResult Enquiry()
        {
            List<TBL_Contact1> Lst = null;
            Lst = db.TBL_Contact1.ToList();

            return View(Lst);
        }
        public void DeleteCon()
        {
            try
            {
                string m = Request.QueryString["m"];
                TBL_Contact1 tbl = db.TBL_Contact1.SingleOrDefault(x => x.Email == m);
                db.TBL_Contact1.Remove(tbl);
                db.SaveChanges();
                Response.Write("<script>alert('request delete successfull');window.location.href='/Addmin/Enquiry'</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('not deleted');window.location.href='/Addmin/Enquiry'</script>");
            }
        }
        public void logout()
        {
            Session.Abandon();
            Response.Write(" <script>alert('logout');window.location.href='/Home/Login'</script>");
        } //get action coll
        [HttpGet]
        public ActionResult RecordUpdate()
        {
            string Email = Request.QueryString["u"];
            
            
            
          
            TBL_Register reg = db.TBL_Register.SingleOrDefault(x => x.Email == Email);
            return View(reg);
        }

        [HttpPost]
        public void RecordUpdate(TBL_Register reg, string Email)
        {
            TBL_Register rg = db.TBL_Register.SingleOrDefault(x => x.Email == Email);
            try
            {
                HttpPostedFileBase file = Request.Files["profile"];

                if (file.FileName != "")
                {
                    rg.Name = reg.Name;
                    rg.Mobile = reg.Mobile;
                    rg.Password = reg.Password;
                    rg.profile = reg.profile;
                    db.SaveChanges();
                    file.SaveAs(Server.MapPath("~/Content/Profile/" + file.FileName));
                    Response.Write("<script>alert('Record Update successfully');window.loction.href='/Addmin/RegistrstionManger'</script>");



                }
                else
                {
                    TBL_Register rt = db.TBL_Register.SingleOrDefault(x => x.Email == Email);
                    rt.Name = reg.Name;
                    rt.Mobile = reg.Mobile;
                    rt.Password = reg.Password;
                    rt.profile = reg.profile;
                    db.SaveChanges();
                    file.SaveAs(Server.MapPath("~/Content/Profile/" + file.FileName));
                    Response.Write("<script>alert('Record  not Update successfully');window.loction.href='/Addmin/RegistrstionManger'</script>");

                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Record Not Update successfully');window.loction.href='/Addmin/RegistrstionManger'</script>");

            }
        }
        public ActionResult ChangePassword1()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ChangePassword1(string oldpassword,string newpassword,string   conformpassword)
        {
            if (newpassword == conformpassword)
            {
                string UserId = Session["aid"].ToString();               
                TBL_login lg = db.TBL_login.Where(x => x.Password == oldpassword && x.UserId == UserId).SingleOrDefault();
                
                lg.Password = oldpassword;
                db.SaveChanges();
                Response.Write("<script>alert('Your Password Change  successfully');window.loction.href='/Addmin/ChangePassword1'</script>");


            }
            else
            {
                Response.Write("<script>alert('Your Password Change Not  successfully');window.loction.href='/Addmin/ChangePassword1'</script>");

            }

            return View();
        }
          
    }

}
