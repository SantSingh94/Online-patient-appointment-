﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Online_Patient_Appoientment.Models;

namespace Online_Patient_Appoientment.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        opaEntities db = new opaEntities();

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult About()
        {
            return View();
        }
        public ActionResult 
            Reviews()
        {
            return View();
        }
        public ActionResult Services()
        {
            return View();
        }
       
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(TBL_login lg)
        {
            try
            {
                TBL_login t1 = db.TBL_login.Where(x => x.UserId == lg.UserId && x.Password == lg.Password).SingleOrDefault();
                if (t1 != null)
                {
                    Session["aid"] = t1.UserId; //Set Session
                    Response.Write("<script>alert('Welcome to admin zone');window.location.href='/Addmin/Index'</script>");
                }
                else
                {
                    Response.Write("<script>alert('Invalid user id or password')</script>");
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Invalid user id or password')</script>");
            }
            return View();
        }
        //http get action   
        public ActionResult Contect()
        {
            return View(); 
        }
        //use for save record code in contact
        [HttpPost]
        public ActionResult Contect(TBL_Contact1 Con)
        {
            try
            {
                db.TBL_Contact1.Add(Con);
                db.SaveChanges();
                Response.Write("<script>alert('Record Save Successfully')</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Record Not Save ')</script>");
            }
            return View();
        }
        public ActionResult Readmore()
        {
            return View();
        }
        //get action 
        public ActionResult Register()
        {   
            return View();
        }
        //save 
        [HttpPost]
        public ActionResult Register(TBL_Register Reg,string hidden,string ct1)
        {
            try
            {
                if (hidden == ct1)
                {
                    //profile code
                    HttpPostedFileBase file = Request.Files["profile"];
                    Reg.profile = file.FileName;
                    file.SaveAs(Server.MapPath("~/Content/Profile/" + file.FileName));
                    //Get date and 
                    Reg.RegDate = DateTime.Now;
                    //end date & time
                    db.TBL_Register.Add(Reg);
                    db.SaveChanges();
                    Response.Write("<script>alert('Registeration Succesfuly')</script>");

                }
                else
                {
                    Response.Write("<script>alert('Invialid Captcher Code')</script>");

                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Registeration Not Succesfuly')</script>");

            }
                return View();
        }
         
        public ActionResult Review()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Review(TBL_Reviews feed )
       
        {
            try
            {


                db.TBL_Reviews.Add(feed);
                db.SaveChanges();
                Response.Write("<script>alert('Review Save Successfully')</script>");

               
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('Review Not Succesfuly')</script>");

            }
                return View();
        }
        public ActionResult UserDash()
        {
            return View();
        }
       
    }
}
